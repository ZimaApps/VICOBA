package com.zimaapps.vicoba;

public class storage {
    public static String kiingilio = "";
    public static String ada = "";
    public static String hisa = "";
    public static String faini = "";
    public static String chini = "";
    public static boolean state = false;
    public static String mikopo = "";
}
