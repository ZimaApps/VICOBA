package com.zimaapps.vicoba;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import static com.zimaapps.vicoba.storage.kiingilio;
import static com.zimaapps.vicoba.storage.mikopo;

/**
 * A simple {@link Fragment} subclass.
 */
public class StatusFragment extends Fragment {
    public View mikopoSectionView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true);
        mikopoSectionView = inflater.inflate(R.layout.fragment_status, container, false);



        ////////////////////////////MIKOPO YES NO LISTERNERS/////////////////////////////////
        RadioButton mikopondioradio = mikopoSectionView.findViewById(R.id.mikopondio);
        mikopondioradio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((AccountSettings)getActivity()).Section = "mikopo";
                ((AccountSettings)getActivity()).thevalue = "yes";
                mikopo = "yes";
                ((AccountSettings)getActivity()).new saveFragmentData().execute();
                //mikopoSectionView.findViewById(R.id.kiingiliodata).setVisibility(View.VISIBLE);

            }
        });
        RadioButton mikopohapanaradio = mikopoSectionView.findViewById(R.id.mikopohapana);
        mikopohapanaradio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((AccountSettings)getActivity()).what = "mikopo";
                ((AccountSettings)getActivity()).thevalue = "no";
                mikopo = "no";
                ((AccountSettings)getActivity()).new saveFragmentData().execute();

            }
        });
        ///////////////////////////////////////////////////////////////////////////////////////

        return mikopoSectionView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_status, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_call) {
            Toast.makeText(getActivity(), "Clicked on " + item.getTitle(), Toast.LENGTH_SHORT)
                    .show();
        }
        return true;
    }
}
