package com.zimaapps.vicoba.ui;

/**
 * Created by vihaan on 18/06/17.
 */

public class Database {

    public static final String NODE_USERS = "users";
    public static final String NODE_USER_CHATS = "users-chats";
    public static final String NODE_MESSAGES = "messages";

}
